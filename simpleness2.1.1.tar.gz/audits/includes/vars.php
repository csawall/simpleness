<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

$debug=0;
$companyname = "COMPANY";
# Define path to zip command
$zipprog = "/usr/bin/gzip -9";
# Define path to mail program
$mailprog = "/usr/bin/mail";
# Define if you want to warn InfoSec that someone just initiated a Nessus scan
# 0 = NO / 1 = YES
$send2infosec = 1;
# Define expression to validate proper email adress
$email_exp = "^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$";
# Define default email domain for users
$emaildomain = "COMPANY.com";
# Define where the warning email should go.  Multiple emails should be space delimited
$infosecemail = "ADMIN@COMPANY.com";
# Define the root where the main audits webpage is located
$rooturl =" https://YOURSERVER/audits/";
# Define root directory
$rootdir = "/srv/www/htdocs/audits";
# Define directory where Nessus reports will be stored
$filedir = "$rootdir/ainfo";
# Same defined directory, but in short form
$shortfiledir = "./ainfo";  #for displaying file later
# Define default limit of hosts to display on server page
$deflimit = "25";
# Define path to SUDO, we'll need it because of how we're starting the job
$sudocommand = "/usr/bin/sudo -u";
$apacheuser = "wwwrun";
# Define path to Nessus and associated variables
$nessuscommand = "/opt/nessus/bin/nessus";
$nessuscmd = "$sudocommand $apacheuser $nessuscommand";
$nessusmsrc = "$rootdir/rcfiles/.nessusrc.ms";
$nessusuxrc = "$rootdir/rcfiles/.nessusrc.ux";
$nessushost = "localhost";
$nessusport = "1241";
$nessususer = "NESUSER";
$nessuspwd = "NESPASSWORD";
$nessusoutput = "nbe";
# Define if you want users to be able to configure custom nessusrc files
# 0 = NO / 1 = YES
$customnrc = 1;
# Define default families for Nessus scans if custom files are allowed
# Definition for Windows based systems
$defmsnrc = array("Backdoors","CGI abuses","CGI abuses : XSS","FTP","Gain a shell remotely","Gain root remotely","General","Misc.","Peer-To-Peer File Sharing","Remote file access","RPC","Service detection","Settings","SMTP problems","SNMP","Useless services","Web Servers","Windows","Windows : Microsoft Bulletins","Windows : User management");
# Definition for Unix based systems
$defuxnrc = array("Backdoors","CGI abuses","CGI abuses : XSS","Default Unix Accounts","FTP","Gain a shell remotely","Gain root remotely","General","Misc.","Remote file access","RPC","Service detection","Settings","SMTP problems","SNMP","Useless services","Web Servers");
# Define path to update-nessusrc
# http://www.tifaware.com/perl/update-nessusrc/
$updatenrccmd = "$rootdir/rcfiles/update-nessusrc";
# Define directory to store custom nessusrc files
$userdir = "$rootdir/users";
# Define path to Nessus NBE Importer
$dbimportcmd = "/srv/www/cgi-bin/importness.pl";
# Define vars to connect to MySQL
$dbhst="localhost";
$dbusr="nesuser";
$dbpwd="PASSWORD";
$dbnme="nessus";
# Define your risk level.  Directly correlated to settings in importness.pl.
$highrisk1 = "3";
$medrisk1 = "2";
$lowrisk1 = "1";

# Connection info for user database
$vauthsrvr="localhost";
$vauthusr="vauthuser";
$vauthpwd="PASSWORD";
$vauthdb="vauth";

# Connection info for DB backup user
$dbbkupusr="dbbackup";
$dbbkuppwd="PASSWORD";

# List of words that can not be used in the server list
$banlist = array ( "insert", "select", "update", "delete", "distinct", "having", "truncate", "replace", "handler", "like", "procedure", "limit", "order by", "group by", "asc", "desc" ); 
# removed "as" and "or"

# Main part of URL to link to all of the articles on Nessus about each vuln
$nessusidlink = "http://www.nessus.org/plugins/index.php?view=single&id=";
# Link to view all available plugins
$pluginslink = "http://cgi.nessus.org/plugins/dump.php3?viewby=family";
# Link to SANS Top 20
$sans20url = "http://www.sans.org/top20/";
?>
