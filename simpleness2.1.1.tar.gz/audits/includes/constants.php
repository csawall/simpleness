<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

$version="2.1.1";

#set the current quarter based on month
if(date("n") == 1 || date("n") == 2 || date("n") == 3) 
	{
	 $qrtr = "1Q"; 
	 $oldyear = date("y")-"1"; 
	 if($oldyear < 10) {$prevqrtr = "4Q0".$oldyear;}
	 else {$prevqrtr = "4Q".$oldyear;}
	}
if(date("n") == 4 || date("n") == 5 || date("n") == 6) {$qrtr = "2Q"; $prevqrtr = "1Q".date("y");}
if(date("n") == 7 || date("n") == 8 || date("n") == 9) {$qrtr = "3Q"; $prevqrtr = "2Q".date("y");}
if(date("n") == 10 || date("n") == 11 || date("n") == 12) {$qrtr = "4Q"; $prevqrtr = "3Q".date("y");}

# connect to the db
$link = mysql_connect('localhost',$dbusr,$dbpwd) or die ('Could not connect: ' . mysql_error());
$connected = mysql_select_db($dbnme) or die( 'Unable to select database');

# Find quarters
$query = 'SELECT DISTINCT quarter FROM quarters';
$result = mysql_query($query) or die ('Query failed: ' . mysql_error());

?>
