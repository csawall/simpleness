-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 24, 2006 at 12:56 PM
-- Server version: 4.1.13
-- PHP Version: 4.4.0
-- 
-- Database: `vauth`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `authteam`
-- 

CREATE TABLE `authteam` (
  `id` int(4) NOT NULL auto_increment,
  `teamname` varchar(25) NOT NULL default '',
  `teamlead` varchar(25) NOT NULL default '',
  `status` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `teamname` (`teamname`,`teamlead`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `authteam`
-- 

INSERT INTO `authteam` VALUES (1, 'Ungrouped', 'sa', 'active');
INSERT INTO `authteam` VALUES (2, 'Admin', 'sa', 'active');
INSERT INTO `authteam` VALUES (3, 'Temporary', 'sa', 'active');
INSERT INTO `authteam` VALUES (7, 'Group 1', 'sa', 'active');
INSERT INTO `authteam` VALUES (8, 'Group 2', 'test', 'active');
INSERT INTO `authteam` VALUES (9, 'Group 3', 'admin', 'active');
INSERT INTO `authteam` VALUES (10, 'Nessus', 'sa', 'active');

-- --------------------------------------------------------

-- 
-- Table structure for table `authuser`
-- 

CREATE TABLE `authuser` (
  `id` int(11) NOT NULL auto_increment,
  `uname` varchar(25) NOT NULL default '',
  `passwd` varchar(32) NOT NULL default '',
  `team` varchar(25) NOT NULL default '',
  `level` int(4) NOT NULL default '0',
  `status` varchar(10) NOT NULL default '',
  `lastlogin` datetime default NULL,
  `logincount` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

-- 
-- Dumping data for table `authuser`
-- 

INSERT INTO `authuser` VALUES (1, 'sa', '5f4dcc3b5aa765d61d8327deb882cf99', 'Admin', 1, 'active', '2006-01-23 10:39:53', 2);
INSERT INTO `authuser` VALUES (2, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'Admin', 1, 'active', '2006-01-23 10:45:40', 28);
INSERT INTO `authuser` VALUES (3, 'test', '9df3b01c60df20d13843841ff0d4482c', 'Temporary', 999, 'inactive', '2003-04-03 00:00:34', 0);
INSERT INTO `authuser` VALUES (29, 'nesuser', '5f4dcc3b5aa765d61d8327deb882cf99', 'Nessus', 6, 'active', '2006-01-24 10:43:36', 9);
