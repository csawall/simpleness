-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 11, 2007 at 07:54 AM
-- Server version: 4.1.13
-- PHP Version: 4.4.0
-- 
-- Database: `nessus`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `quarters`
-- 

CREATE TABLE `quarters` (
  `id` int(11) NOT NULL auto_increment,
  `host` varchar(30) NOT NULL default '',
  `quarter` varchar(4) NOT NULL default '',
  `os` varchar(4) NOT NULL default '',
  `scanned` char(1) NOT NULL default 'N',
  `hostinfo` text,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `udx1_quarter` (`quarter`,`host`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table `results`
-- 

CREATE TABLE `results` (
  `id` int(11) NOT NULL auto_increment,
  `quarter` varchar(4) NOT NULL default '',
  `os` varchar(4) NOT NULL default '',
  `domain` varchar(40) NOT NULL default '',
  `host` varchar(40) NOT NULL default '',
  `service` varchar(40) NOT NULL default '',
  `scriptid` varchar(40) NOT NULL default '',
  `risk` varchar(40) NOT NULL default '',
  `msg` text,
  `falsepos` char(1) NOT NULL default 'N',
  `notes` text,
  `closedate` varchar(20) default NULL,
  `owner` varchar(30) default NULL,
  `status` text,
  PRIMARY KEY  (`id`),
  KEY `host` (`host`),
  KEY `host_2` (`host`,`service`,`risk`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table `scheduled`
-- 

CREATE TABLE `scheduled` (
  `id` int(11) NOT NULL auto_increment,
  `time` varchar(8) NOT NULL default '',
  `job` text NOT NULL,
  `jobdisp` text NOT NULL,
  `jobdir` text NOT NULL,
  `user` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `scanreason` varchar(20) NOT NULL default '',
  `sendinfosec` int(1) NOT NULL default '0',
  `infosecemail` text NOT NULL,
  `convertcmd` text NOT NULL,
  `dbcmd` text NOT NULL,
  `dbinput` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table `timestamps`
-- 

CREATE TABLE `timestamps` (
  `id` int(11) NOT NULL auto_increment,
  `quarter` varchar(4) NOT NULL default '',
  `os` varchar(4) NOT NULL default '',
  `unused` varchar(40) NOT NULL default '',
  `host` varchar(40) NOT NULL default '',
  `progress` varchar(40) NOT NULL default '',
  `timestamp` varchar(40) NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `host` (`host`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

