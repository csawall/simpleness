--
-- Index changes
--

ALTER TABLE `quarters` ADD UNIQUE `udx1_quarter` ( `quarter` , `host` , `id` );  
ALTER TABLE `results` DROP INDEX `host_2` ,
ADD INDEX `host_2` ( `host` , `service` , `risk` );

-- 
-- Table structure for table `scheduled`
-- 

CREATE TABLE `scheduled` (
  `id` int(11) NOT NULL auto_increment,
  `time` varchar(8) NOT NULL default '',
  `job` text NOT NULL,
  `jobdisp` text NOT NULL,
  `jobdir` text NOT NULL,
  `user` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `scanreason` varchar(20) NOT NULL default '',
  `sendinfosec` int(1) NOT NULL default '0',
  `infosecemail` text NOT NULL,
  `convertcmd` text NOT NULL,
  `dbcmd` text NOT NULL,
  `dbinput` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
