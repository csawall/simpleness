<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

define( "DATABASE_SERVER", $vauthsrvr );
define( "DATABASE_USERNAME", $vauthusr );
define( "DATABASE_PASSWORD", $vauthpwd );
define( "DATABASE_NAME", $vauthdb );

//connect to the database
$mysql = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD) or die(mysql_error());

//select the database
$connected = mysql_select_db( DATABASE_NAME );

//asign the data passed from Flex to variables
$admtype = $_REQUEST["admtype"];
$username = mysql_real_escape_string($_REQUEST["username"]);
$group = mysql_real_escape_string($_REQUEST["group"]);
$level = mysql_real_escape_string($_REQUEST["level"]);
$status = mysql_real_escape_string($_REQUEST["status"]);
if($_REQUEST["oldpwd"]) {$oldpassword = mysql_real_escape_string($_REQUEST["oldpwd"]);}
if($_REQUEST["newpwd"]) {$newpassword = mysql_real_escape_string($_REQUEST["newpwd"]);}

$debuginfo ='';
if($debug)
{
 $debuginfo .= "Type = $admtype\n";
 $debuginfo .= "User = $username\n";
 $debuginfo .= "Level = $level\n";
 $debuginfo .= "Status = $status\n";
 if($oldpassword || $newpassword) {$debuginfo .= "Password change requested\n";}
}

//start outputting the XML
$return = "<changesuccess>";
if(!$connected) {$return .= 'nodb</changesuccess>'; bedone($return,$debug,$debuginfo);} 
if(!$admtype) {$return .= 'notype</changesuccess>'; bedone($return,$debug,$debuginfo);}
if(!$username) {$return .= 'nousr</changesuccess>'; bedone($return,$debug,$debuginfo);}
if(($admtype!="usrchg") && (!$level)) {$return .= 'nolvl</changesuccess>'; bedone($return,$debug,$debuginfo);}
if($oldpassword)
{
 if($oldpassword == $newpassword) {$return .= 'samepwd</changesuccess>'; bedone($return,$debug,$debuginfo);}
 if(($oldpassword == "") && ($admtype != "usrchg")) {$return .= 'blankpwd</changesuccess>'; bedone($return,$debug,$debuginfo);}
}
if($newpassword)
{
 if(($newpassword == "") && ($admtype == "add")) {$return .= 'blankpwd</changesuccess>'; bedone($return,$debug,$debuginfo);}
}

if($admtype == "usrchg")
{
 //Query the database to see if the given username/password combination is valid.
 $query = "UPDATE authuser SET passwd=MD5('$newpassword') WHERE uname = '$username'";
 $result = mysql_query($query) or die ("Query failed: " . mysql_error());
 $return .= 'pwdchanged</changesuccess>'; bedone($return,$debug,$debuginfo);
}
if($admtype == "mod")
{
 if (trim($newpassword == ''))
 {
  $query = "UPDATE authuser SET team='$group', level='$level', status='$status' WHERE uname='$username'";
 }
 else
 {
  $query = "UPDATE authuser SET passwd=MD5('$newpassword'), team='$group', level='$level', status='$status' WHERE uname='$username'";
 }
 if (($username=="sa" AND $status=="inactive")) {$return .= 'nosainactive</changesuccess>'; bedone($return,$debug,$debuginfo);}
 elseif (($username=="admin" AND $status=="inactive")) {$return .= 'noadmininactive</changesuccess>'; bedone($return,$debug,$debuginfo);}
 else 
 {
  $result = mysql_query($query);
  $return .= 'usermodded</changesuccess>'; bedone($return,$debug,$debuginfo);
 }
}
if($admtype == "add")
{
 $qUserExists = "SELECT * FROM authuser WHERE uname='$username'";
 $query = "INSERT INTO authuser(uname, passwd, team, level, status, lastlogin, logincount) VALUES ('$username', MD5('$newpassword'), '$group', '$level', '$status', '', 0)";
 $user_exists = mysql_query($qUserExists);
 if (mysql_num_rows($user_exists) > 0) {$return .= 'userexists</changesuccess>'; bedone($return,$debug,$debuginfo);}
 else 
 {
  $result = mysql_query($query);
  $return .= 'useradded</changesuccess>'; bedone($return,$debug,$debuginfo);
 }
}
if($admtype == "del")
{
 $query = "DELETE FROM authuser WHERE uname='$username'";
 if($username == "sa") {$return .= 'nodelsa</changesuccess>'; bedone($return,$debug,$debuginfo);} 
 elseif($username == "admin") {$return .= 'nodeladmin</changesuccess>'; bedone($return,$debug,$debuginfo);} 
 elseif($username == "test") {$return .= 'nodeltest</changesuccess>'; bedone($return,$debug,$debuginfo);} 
 else 
 {
  $result = mysql_query($query);
  $return .= 'userdeleted</changesuccess>'; bedone($return,$debug,$debuginfo);
 } 
}

//output all the XML

function bedone($return,$debug,$debuginfo) 
{
if($debug)
{
 $myFile = "/tmp/zsn_userupdate_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 if($debuginfo) {fwrite($fh, "$debuginfo\n");}
 fclose($fh);
}

print ($return);
exit;
}
?>
