<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

include '../includes/vars.php';
include '../includes/constants.php';

define( "DATABASE_SERVER", $vauthsrvr );
define( "DATABASE_USERNAME", $vauthusr );
define( "DATABASE_PASSWORD", $vauthpwd );
define( "DATABASE_NAME", $vauthdb );

//connect to the database
$mysql = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD) or die(mysql_error());

//select the database
mysql_select_db( DATABASE_NAME );

//asign the data passed from Flex to variables
$username = mysql_real_escape_string($_REQUEST["username"]);
$password = mysql_real_escape_string($_REQUEST["password"]);

//Query the database to see if the given username/password combination is valid.
$query = "SELECT * FROM authuser WHERE uname = '$username' AND passwd = MD5('$password') AND status <> 'inactive'";
$result = mysql_query($query) or die ("Query failed: " . mysql_error());

//start outputting the XML
$return = "<loginsuccess>";
if(mysql_num_rows($result) == 0) {$return .= 'no</loginsuccess>';}
else
{
 $updaterecords = "UPDATE authuser SET lastlogin = NOW(), logincount = logincount + 1 WHERE uname='$username'";
 $update = mysql_query($updaterecords);
 while ($user = mysql_fetch_array($result))
 {
  $return .= 'yes</loginsuccess>';
  $return .= '<uname>'.$user[uname].'</uname>';
  $return .= '<level>'.$user[level].'</level>';
  $return .= '<team>'.$user[team].'</team>';
 }
 session_start();
 $_SESSION['loggedin']=1;
}
//output all the XML

if($debug)
{
 $myFile = "/tmp/zsn_login_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 fclose($fh);
}

print ($return);

?>
