<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

include '../includes/vars.php';
include '../includes/constants.php';

if (!$connected) {echo 'Could not connect to database<br>';}

if($_REQUEST['scriptid'] && $_REQUEST['qtr'])
{
 $scriptid=$_REQUEST['scriptid'];
 if (ereg("^[0-9]+", $scriptid)) {}
 else { die("Try hacking somebody else's site. (1)"); }

 $qrtr_rpt=$_REQUEST['qtr'];
 if (eregi("^[1234]Q[0-9][0-9]", $qrtr_rpt)) {}
 else { die("Try hacking somebody else's site."); };
}
else { die("Did not get Plugin ID or Quarter information.");}

$query='SELECT DISTINCT host FROM results WHERE scriptid="'.$scriptid.'" AND quarter="'.$qrtr_rpt.'" ORDER BY host';
$result= mysql_query($query) or die('Query failed: ' .mysql_error());
$return = '<hostdetails>';
$return .= '<scriptid>'.$scriptid.'</scriptid>';
while ($row= mysql_fetch_array($result))
{
 $return .= '<details>';
 $return .= '<host>'.$row[host].'</host>';
 $return .= '</details>';
}
$return .= '</hostdetails>';

// Free resultset
mysql_free_result($result);

// Closing connection
mysql_close($link);

if($debug)
{
 $myFile = "/tmp/zsn_hostsaffected_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 fclose($fh);
}

print($return);
?>
