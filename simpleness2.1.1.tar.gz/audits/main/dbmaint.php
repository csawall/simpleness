<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

$dbtype = $_REQUEST["dbtype"];
$qrtrdisp = $_REQUEST["qrtrdisp"];
$backuppath = $_REQUEST["dbbkuppath"];
$nessusdb = $_REQUEST["nessusdb"];
$userdb = $_REQUEST["userdb"];
$zipdb = $_REQUEST["zipdb"];

$return = '<success>';
$debuginfo ='';
if(!$dbtype) {$return .= 'notype</success>'; bedone($return,$debug,$debuginfo);}
if($dbtype == "backup")
{
 if(!$backuppath) {$return .= 'nopath</success>'; bedone($return,$debug,$debuginfo);}
 if(($nessusdb == "false") && ($userdb == "false")) {$return .= 'nodb</success>'; bedone($return,$debug,$debuginfo);}
 $ndbname = "simpleness.nessus.".date("dmyHis");
 $udbname = "simpleness.vauth.".date("dmyHis");
 $ncmd = "mysqldump --user $dbbkupusr --password=$dbbkuppwd $dbnme > $backuppath/$ndbname";
 $ucmd = "mysqldump --user $dbbkupusr --password=$dbbkuppwd $vauthdb > $backuppath/$udbname";
}
else 
{
 if($qrtrdisp == "Select Quarter") 
 {
  $return .= 'noqrtr</success>'; bedone($return,$debug,$debuginfo);
 } 
 else 
 {
  # Multi-delete statement hangs.  Future use?
  #$query = "DELETE quarters,results,timestamps FROM quarters,results,timestamps WHERE quarters.quarter='$qrtrdisp' AND results.quarter='$qrtrdisp' AND timestamps.quarter='$qrtrdisp'";
  $qquery = "DELETE FROM quarters WHERE quarter='$qrtrdisp'";
  $tquery = "DELETE FROM timestamps WHERE quarter='$qrtrdisp'";
  $rquery = "DELETE FROM results WHERE quarter='$qrtrdisp'";
 }
}


if($debug)
{
 $debuginfo .= "DB Type = $dbtype\n";
 $debuginfo .= "Quarter = $qrtrdisp\n";
 $debuginfo .= "Backup Path = $backuppath\n";
 $debuginfo .= "Backup Nessus DB = $nessusdb\n";
 $debuginfo .= "Backup User DB = $userdb\n";
 $debuginfo .= "DB Delete Query (quarters) = $qquery\n";
 $debuginfo .= "DB Delete Query (timestamps) = $tquery\n";
 $debuginfo .= "DB Delete Query (results) = $rquery\n";
 $debuginfo .= "Nessus DB Output = $ndbname\n";
 $debuginfo .= "User DB Output = $udbname\n";
 $debuginfo .= "Nessus Backup CMD = $ncmd\n";
 $debuginfo .= "User Backup CMD = $ucmd\n";
 $debuginfo .= "Zip DB = $zipdb\n";
}

if($dbtype == "backup")
{
 if($nessusdb == "true")
 {
  if($debug) {$debuginfo .= "Running backup for the Nessus DB.\n";}
  $nerr = exec($ncmd);
  if($zipdb == "true") {$nzerr = exec("$zipprog $backuppath/$ndbname");}
  if($debug) {$debuginfo .= "Nessus Backup Err = $nerr\n";}
 }
 if($userdb == "true")
 {
  if($debug) {$debuginfo .= "Running backup for the user DB.\n";}
  $uerr = exec($ucmd);
  if($zipdb == "true") {$uzerr = exec("$zipprog $backuppath/$udbname");}
  if($debug) {$debuginfo .= "User Backup Err = $uerr\n";}
 } 
 $return .= 'bsuccess</success>';
 bedone($return,$debug,$debuginfo);
}

if($dbtype == "delete")
{
 define( "DATABASE_SERVER", $dbhst );
 define( "DATABASE_USERNAME", $dbusr );
 define( "DATABASE_PASSWORD", $dbpwd );
 define( "DATABASE_NAME", $dbnme );

 //connect to the database
 $mysql = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD) or die(mysql_error());

 //select the database
 $connected = mysql_select_db( DATABASE_NAME );

 $qresult = mysql_query($qquery);
 $debuginfo .= "Err from deletion of quarters info = ".mysql_error()."n";
 $qaffrows = mysql_affected_rows();
 if($qaffrows <=0) {$return .= 'qfailed</success>'; bedone($return,$debug,$debuginfo);}

 $tresult = mysql_query($tquery);
 $debuginfo .= "Err from deletion of timestamps info = ".mysql_error()."\n";
 $taffrows = mysql_affected_rows();
 if($taffrows <=0) {$return .= 'tfailed</success>'; bedone($return,$debug,$debuginfo);}

 $rresult = mysql_query($rquery);
 $debuginfo .= "Err from deletion of results info = ".mysql_error()."\n";
 $raffrows = mysql_affected_rows();
 if($raffrows <=0) {$return .= 'rfailed</success>'; bedone($return,$debug,$debuginfo);}
 
 $affrows = $qaffrows + $taffrows + raffrows;
 if($affrows >0) {$debuginfo .= "Rows affected = $affrows\n"; $return .= 'dsuccess</success>';}
 else {$debuginfo .= "Rows affected = $affrows\n"; $return .= 'failed</success>';}

 bedone($return,$debug,$debuginfo);
}


function bedone($return,$debug,$debuginfo)
{
 if($debug)
 {
  $myFile = "/tmp/zsn_dbmaint_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  if($debuginfo) {fwrite($fh, "$debuginfo\n");}
  fclose($fh);
 }

print($return);
exit;
}

?>
