<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

$username = $_REQUEST["username"];
$nes_email = trim(strip_tags($_REQUEST["nes_email"]));
$scantype = $_REQUEST["scantype"];
$scanreason = $_REQUEST["scanreason"];
$ostype = $_REQUEST["ostype"];
$usecustom = $_REQUEST["usecustom"];
$nes_curqrtr = trim(strip_tags($_REQUEST["nes_curqrtr"]));
$runtime = $_REQUEST["runtime"];
$nes_atjob = $_REQUEST["nes_atjob"];
$nes_hosts = $_REQUEST["nes_hosts"];
$qrtr = $_REQUEST["qrtrdisp"];
$dbinput = $_REQUEST["dbinput"];

# convert for import command
if($ostype == "Microsoft") {$ostype = "msft";}
if($ostype == "Unix") {$ostype = "unix";}

$debuginfo ='';
if($debug)
{
 $debuginfo .= "Username = ".$username."\n";
 $debuginfo .= "User email = ".$nes_email."\n";
 $debuginfo .= "Scan type = ".$scantype."\n";
 $debuginfo .= "Scan reason = ".$scanreason."\n";
 $debuginfo .= "OS type = ".$ostype."\n";
 $debuginfo .= "Use custom = ".$usecustom."\n";
 $debuginfo .= "Current quarter = ".$nes_curqrtr."\n";
 $debuginfo .= "Runtime = ".$runtime."\n";
 $debuginfo .= "AT Job = ".$nes_atjob."\n";
 $debuginfo .= "Hosts = ".$nes_hosts."\n";
 $debuginfo .= "Quarter = ".$qrtr."\n";
 $debuginfo .= "Insert into prod DB = ".$dbinput."\n";
}

$return = '<nessuccess>';
if (!$username) {$return .= 'nousr</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$nes_email) {$return .= 'noemail</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$scantype) {$return .= 'nostype</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$scanreason) {$return .= 'noreason</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$ostype) {$return .= 'noos</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$usecustom) {$return .= 'nonrc</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$nes_curqrtr) {$return .= 'noqrtr</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$runtime) {$return .= 'noruntime</nessuccess>'; bedone($return,$debug,$debuginfo);}
if (!$nes_hosts) {$return .= 'nohosts</nessuccess>'; bedone($return,$debug,$debuginfo);}
if ($runtime == "Schedule Run Time") 
{
 if (!$nes_atjob) {$return .= 'noatj</nessuccess>'; bedone($return,$debug,$debuginfo);}
}
if ($runtime == "Run Now") {$nes_atjob = "00000001";}

$dstfile=$userdir.DIRECTORY_SEPARATOR.$username.'/.nessusrc.'.$username;

if (eregi($email_exp, $nes_email)) {} else {$return .= 'emailwrong</nessuccess>'; bedone($return,$debug,$debuginfo);}
if($ostype == "msft")
{
 if (!file_exists($nessusmsrc)) {$return .= 'nomsnrc</nessuccess>'; bedone($return,$debug,$debuginfo);}
 if($debug) {$debuginfo .= "Default rc file = ".$nessusuxrc."\n";}
}
if($ostype == "unix")
{
 if (!file_exists($nessusuxrc)) {$return .= 'nouxnrc</nessuccess>'; bedone($return,$debug,$debuginfo);}
 if($debug) {$debuginfo .= "Default rc file = ".$nessusuxrc."\n";}
}
if($usecustom == "true")
{
 if($debug)
 {
   $debuginfo .= "Using custom nessusrc file.\n";
   $debuginfo .= "Custom rc file = ".$dstfile."\n";
 }
 if (!file_exists($dstfile)) {$return .= 'nocnrc</nessuccess>'; bedone($return,$debug,$debuginfo);}
}
//Verify quarter variable in proper format from URL input
if (eregi("^[1234]Q[0-9][0-9]", $nes_curqrtr)) {} else {$return .= 'wrongqrtr</nessuccess>'; bedone($return,$debug,$debuginfo);}
if($scanreason == "Test Only") { $filename = $username.'_TEST_'.$nes_curqrtr.$ostype.date("dmyHis");}
if($scanreason == "Quarterly Scan") { $filename = $username.'_'.$qrtr.$ostype.date("dmyHis");}
if($debug) {$debuginfo .= "Output filename = ".$filename."\n";}
$fp = fopen("$filedir/$filename", "w");

#pull each host into array and then check host for proper text
$hosts = preg_split("/[\s]+/", $nes_hosts);
$hostscount = count($hosts)-1;
if($debug) {$debuginfo .= "Number of hosts to scan = ".$hostscount."\n";}
   $hoststart = 0;
   do {
    $host = trim(strip_tags($hosts[$hoststart]));
    $host = preg_replace('/^\n+|\n+$/', '', $host);
    if (ereg("^[a-zA-Z0-9]+|\.-$", $host) || !($host)) {} else {$return .= 'wronghostfmt</nessuccess>'; bedone($return,$debug,$debuginfo);}
    if($hostscount > $hoststart) {fwrite($fp, "$host\n");}
    if($hostscount == $hoststart) {fwrite($fp, "$host");}
    $hoststart = $hoststart+1;
    } while ($hostscount >= $hoststart);
   fclose($fp);

if($usecustom == "false")
{
 if($ostype == "msft") {$cmd = "$nessuscmd -c $nessusmsrc -x -q $nessushost $nessusport $nessususer $nessuspwd -T $nessusoutput $filedir/$filename $filedir/$filename.$nessusoutput";}
 if($ostype == "unix") {$cmd = "$nessuscmd -c $nessusuxrc -x -q $nessushost $nessusport $nessususer $nessuspwd -T $nessusoutput $filedir/$filename $filedir/$filename.$nessusoutput";}
}
else
{
 $cmd = "$nessuscmd -c $dstfile -x -q $nessushost $nessusport $nessususer $nessuspwd -T $nessusoutput $filedir/$filename $filedir/$filename.$nessusoutput";
}
$convertcmd = "$nessuscmd -i $filedir/$filename.$nessusoutput -o $filedir/$filename.html";
if($dbinput == "true") {$dbcmd = "$dbimportcmd -v -f $filedir/$filename.$nessusoutput -o $ostype -q $qrtr";}
else {$dbcmd = "0";}

$query = "INSERT INTO scheduled(time, job, jobdisp, jobdir, user, email, scanreason, sendinfosec, infosecemail, convertcmd, dbcmd, dbinput) VALUES ('$nes_atjob', '$cmd', '$filename', '$filedir', '$username', '$nes_email', '$scanreason', '$send2infosec', '$infosecemail', '$convertcmd', '$dbcmd', '$dbinput')";
$result = mysql_query($query);
$debuginfo .= '<mysqlerr>'.mysql_error().'</mysqlerr>';

$return .= 'success</nessuccess>';
bedone($return,$debug,$debuginfo);

function bedone($return,$debug,$debuginfo)
{
 if($debug)
 {
  $myFile = "/tmp/zsn_runnessus_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  if($debuginfo) {fwrite($fh, "$debuginfo\n");}
  fclose($fh);
 }

print($return);
exit;
}


?>
