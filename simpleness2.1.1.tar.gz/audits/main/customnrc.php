<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

$sans20 = $_REQUEST["sans20"];
$dangerplugs = $_REQUEST["dangerplugs"];
$families = $_REQUEST["families"];
$excludes = $_REQUEST["excludes"];
$includes = $_REQUEST["includes"];
$username = $_REQUEST["username"];

$debuginfo ='';
if($debug)
{
 $debuginfo .= "Username = ".$username."\n";
 $debuginfo .= "Sans top 20 set to = ".$sans20."\n";
 $debuginfo .= "Scan with DoS plugins = ".$dangerplugs."\n";
 $debuginfo .= "Families to scan = ".$families."\n";
 $debuginfo .= "Exclude plugins = ".$excludes."\n";
 $debuginfo .= "Include plugins = ".$includes."\n";
}

$return = '<createsuccess>';
if(!$username) {$return .= 'nousr</createsuccess>'; bedone($return,$debug,$debuginfo);}
if((!$families) && (!$sans20)) {$return .= 'nofams</createsuccess>'; bedone($return,$debug,$debuginfo);}

$updatecmd = $updatenrccmd;

if(!$sans20)
{
 if($dangerplugs) {$updatecmd .= ' -c "_all_"';}
# else { $updatecmd .= ' -c "!denial,!destructive_attack,!flood,!kill_host"';}
 if($families) {$updatecmd .= ' -f "'.$families.'"';}
 if($excludes) {$updatecmd .= ' -x "'.$excludes.'"';}
 if($includes) {$updatecmd .= ' -i "'.$includes.'"';}
}
else {$updatecmd .= ' -t';}

if(!is_dir($userdir.DIRECTORY_SEPARATOR.$username)) {mkdir($userdir.DIRECTORY_SEPARATOR.$username,0777);}
$srcfile=$nessusmsrc;
$dstfile=$userdir.DIRECTORY_SEPARATOR.$username.'/.nessusrc.'.$username;
if(!file_exists($dstfile)) {copy($srcfile,$dstfile);}
$updatecmd .= ' '.$dstfile;

if($debug) {$debuginfo .= "Update Command = ".$updatecmd."\n";}
$runupdate = shell_exec($updatecmd);
$return .= 'created</createsuccess>';

bedone($return,$debug,$debuginfo);

function bedone($return,$debug,$debuginfo)
{
 if($debug)
 {
  $myFile = "/tmp/zsn_customnrc_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  if($debuginfo) {fwrite($fh, "$debuginfo\n");}
  fclose($fh);
 }

print($return);
exit;
}

?>
