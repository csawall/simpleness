<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

//asign the data passed from Flex to variables
$id = mysql_real_escape_string($_REQUEST["id"]);
$notes = mysql_real_escape_string($_REQUEST["notes"]);
$status = mysql_real_escape_string($_REQUEST["status"]);
$owner = mysql_real_escape_string($_REQUEST["owner"]);
$closedate = mysql_real_escape_string($_REQUEST["closedate"]);
$falsepos = mysql_real_escape_string($_REQUEST["falsepos"]);

$debuginfo ='';
if($debug)
{
 $debuginfo .= '<debuginfo>';
 $debuginfo .= "<settings>id=$id -- notes=$notes -- status=$status -- owner=$owner -- closedate=$closedate -- falsepos=$falsepos</settings>";
}

//start outputting the XML
$return = "<changesuccess>";
if(!$connected) {$return .= 'nodb</changesuccess>'; bedone($return,$debug);}
if(!$id) {$return .= 'nodbid</changesuccess>'; bedone($return,$debug);} 

//Query the database to see if the given username/password combination is valid.
$query = "UPDATE results SET ";
if(!$notes) {$query .= "notes=NULL,";}
else {$query .= "notes='$notes',";}
if(!$status) {$query .= "status=NULL,";}
else {$query .= "status='$status',";}
if(!$owner) {$query .= "owner=NULL,";}
else {$query .= "owner='$owner',";}
if(!$closedate) {$query .= "closedate=NULL,";}
else {$query .= "closedate='$closedate',";}
if($falsepos == "N") {$query .= "falsepos='N'";}
else {$query .= "falsepos='Y'";}
$query .= " WHERE id='$id'";
$result = mysql_query($query);# or die ("Query failed: " . mysql_error());

if($debug)
{
 $debuginfo .= '<query>'.$query.'</query>';
 $debuginfo .= '<mysqlerr>'.mysql_error().'</mysqlerr>';
 $debuginfo .= '</debuginfo>';
}

if(!mysql_error()) {$return .= "updated</changesuccess>";}
bedone($return,$debug,$debuginfo);

//output all the XML

function bedone($return,$debug,$debuginfo)
{
 if($debug)
 {
  $myFile = "/tmp/zsn_changevulnstats_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  fwrite($fh, "$debuginfo\n");
  fclose($fh);
 }
print ($return);
exit;
}
?>
