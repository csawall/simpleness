<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

define( "DATABASE_SERVER", $vauthsrvr );
define( "DATABASE_USERNAME", $vauthusr );
define( "DATABASE_PASSWORD", $vauthpwd );
define( "DATABASE_NAME", $vauthdb );

//connect to the database
$mysql = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD) or die(mysql_error());

//select the database
mysql_select_db( DATABASE_NAME );


//Query the database to see if the given username/password combination is valid.
$query = "SELECT * FROM authuser";
$result = mysql_query($query) or die ("Query failed: " . mysql_error());

//start outputting the XML
$return = "<allusers>";
//gather user info
while ($user = mysql_fetch_array($result))
{
 $return .= '<user>';
 $return .= '<uname>'.$user[uname].'</uname>';
 $return .= '<level>'.$user[level].'</level>';
 $return .= '<status>'.$user[status].'</status>';
 $return .= '<team>'.$user[team].'</team>';
 $return .= '<llogin>'.$user[lastlogin].'</llogin>';
 $return .= '<lcount>'.$user[logincount].'</lcount>';
 $return .= '</user>';
}

//gather group info
$query = "SELECT teamname, teamlead, status FROM authteam";
$result = mysql_query($query) or die ("Query failed: " . mysql_error());

while ($group = mysql_fetch_array($result))
{
 $return .= '<group>';
 $return .= '<teamname>'.$group[teamname].'</teamname>';
 $return .= '<teamlead>'.$group[teamlead].'</teamlead>';
 $return .= '<teamstatus>'.$group[status].'</teamstatus>';
 $return .= '</group>';
}

//set active levels
$return .= '<statusops><status>active</status></statusops>';
$return .= '<statusops><status>inactive</status></statusops>';

$return .= "</allusers>";
//output all the XML

if($debug)
{
 $myFile = "/tmp/zsn_getusers_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 fclose($fh);
}

print ($return);

?>
