<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

$host = $_REQUEST["host"];
$qrtrdisp = $_REQUEST["qrtrdisp"];

$return = '<success>';
$debuginfo ='';
if($debug)
{
 $debuginfo .= "Host = $dbtype\n";
 $debuginfo .= "Quarter = $qrtrdisp\n";
}
if(!$host) {$return .= 'nohost</success>'; bedone($return,$debug,$debuginfo);}
if($qrtrdisp == "Select Quarter")
{
 $return .= 'noqrtr</success>'; bedone($return,$debug,$debuginfo);
}
else
{
 $query = "DELETE quarters,results,timestamps FROM quarters,results,timestamps WHERE (quarters.quarter='$qrtrdisp' AND quarters.host='$host') AND (results.quarter='$qrtrdisp' AND results.host='$host') AND (timestamps.quarter='$qrtrdisp' AND timestamps.host='$host')";
}

if($debug)
{
 $debuginfo .= "Query = $query\n";
}

$result = mysql_query($query);
$debuginfo .= 'MySQL Error = '.mysql_error().'\n';

$affrows = mysql_affected_rows();
if($affrows >0) {$debuginfo .= "Rows affected = $affrows\n"; $return .= 'success</success>';}
else {$debuginfo .= "Rows affected = $affrows\n"; $return .= 'failed</success>';}

bedone($return,$debug,$debuginfo);

function bedone($return,$debug,$debuginfo)
{
 if($debug)
 {
  $myFile = "/tmp/zsn_delhost_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  if($debuginfo) {fwrite($fh, "$debuginfo\n");}
  fclose($fh);
 }

print($return);
exit;
}

?>
