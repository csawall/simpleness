<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

include '../includes/vars.php';
include '../includes/constants.php';

$qrtrdisp = mysql_real_escape_string(urldecode($_REQUEST['qrtrdisp']));
$server = mysql_real_escape_string(urldecode($_REQUEST['server']));
$return = '<hostdetails>';

#if(isset($_REQUEST['server']) && $_REQUEST['qrtrdisp'])
#{
# $server = trim(strip_tags($_REQUEST['server']));
# $qrtr_rpt = trim(strip_tags($_REQUEST['qrtrdisp']));
# //Verify quarter variable in proper format from URL input
# if (eregi("^[1234]Q[0-9][0-9]", $qrtr_rpt)) { } 
# else { die("Try hacking somebody else's site."); }

#$server = trim(str_replace($banlist, '', strtolower($server)));

$query = 'SELECT risk,id,service,scriptid,msg,falsepos,notes,status,closedate,owner FROM results WHERE risk != "0" AND host = "'.$server.'" AND quarter = "'.$qrtrdisp.'" ORDER BY risk DESC';

$vresult = mysql_query($query) or die ('Query failed: ' . mysql_error());
#  $num_rows_risks = mysql_num_rows($vresult);

  while($vrow = mysql_fetch_array($vresult)) 
  {
   $return .= '<riskdetails>';
   $return .= '<id>'.$vrow["id"].'</id>';
   if($vrow["risk"] == "1") {$risk = "Low";}
   if($vrow["risk"] == "2") {$risk = "Medium";}
   if($vrow["risk"] == "3") {$risk = "High";}
   $return .= '<risk>'.$risk.'</risk>';
   $return .= '<service>'.$vrow["service"].'</service>';
   $return .= '<scriptidlink>'.$nessusidlink.$vrow["scriptid"].'</scriptidlink>';
   $return .= '<scriptid>'.$vrow["scriptid"].'</scriptid>';
   #if(eregi("<Directory", $vrow["msg"]))
   #{
   # $desc=eregi_replace("<","&lt;",$vrow["msg"]);
   # $fdesc=eregi_replace(">","&gt;",$desc);
   # $return .= '<description>'.$fdesc.'</description>';
   #} 
   #else {$return .= '<description>'.$vrow["msg"].'</description>';}
   $return .= '<description><![CDATA['.$vrow["msg"].']]></description>';
   #$return .= '<description>'.$vrow["msg"].'</description>';
   #$return .= '<msg>'.$vrow["msg"].'</msg>';
   $return .= '<falsepos>'.$vrow["falsepos"].'</falsepos>';
   $return .= '<notes>'.$vrow["notes"].'</notes>';
   $return .= '<status>'.$vrow["status"].'</status>';
   $return .= '<closedate>'.$vrow["closedate"].'</closedate>';
   $return .= '<owner>'.$vrow["owner"].'</owner>';
   $return .= '</riskdetails>';
  }

$return .= '</hostdetails>';

// Free resultset
mysql_free_result($result);

// Closing connection
mysql_close($link);

if($debug)
{
 $myFile = "/tmp/zsn_hostdetails_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 fclose($fh);
}

print($return); 

?>
