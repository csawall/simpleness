<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

define( "DATABASE_SERVER", $vauthsrvr );
define( "DATABASE_USERNAME", $vauthusr );
define( "DATABASE_PASSWORD", $vauthpwd );
define( "DATABASE_NAME", $vauthdb );

//connect to the database
$mysql = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD) or die(mysql_error());

//select the database
$connected = mysql_select_db( DATABASE_NAME );

//asign the data passed from Flex to variables
$admtype = $_REQUEST["admtype"];
$teamname = mysql_real_escape_string($_REQUEST["teamname"]);
$teamlead = mysql_real_escape_string($_REQUEST["teamlead"]);
$status = mysql_real_escape_string($_REQUEST["status"]);

$debuginfo ='';
if($debug)
{
 $debuginfo .= "Type = $admtype\n";
 $debuginfo .= "Team = $teamname\n";
 $debuginfo .= "Lead = $teamlead\n";
 $debuginfo .= "Status = $status\n";
}

//start outputting the XML
$return = "<changesuccess>";
if(!$connected) {$return .= 'nodb</changesuccess>'; bedone($return,$debug,$debuginfo);} 
if(!$admtype) {$return .= 'notype</changesuccess>'; bedone($return,$debug,$debuginfo);}
if(!$teamname) {$return .= 'nogrp</changesuccess>'; bedone($return,$debug,$debuginfo);}

if($admtype == "grpmod")
{
 $qUpdate = "UPDATE authteam SET teamlead='$teamlead', status='$status' WHERE teamname='$teamname'";
 $qUserStatus = "UPDATE authuser SET status='$status' WHERE team='$teamname'";
 if ($teamname == "Admin" AND $status=="inactive") {$return .= 'noadmininactive</changesuccess>'; bedone($return,$debug,$debuginfo);}
 elseif ($teamname == "Ungrouped" AND $status=="inactive") {$return .= 'noungrpinactive</changesuccess>'; bedone($return,$debug,$debuginfo);}
 else 
 {
  $userresult = mysql_query($qUserStatus);
  $result = mysql_query($qUpdate);
  $return .= 'groupmodded</changesuccess>'; bedone($return,$debug,$debuginfo);
 }
}
if($admtype == "grpadd")
{
 $qGroupExists = "SELECT * FROM authteam WHERE teamname='$teamname'";
 $qInsertGroup = "INSERT INTO authteam(teamname, teamlead, status) VALUES ('$teamname', '$teamlead', '$status')";
 $group_exists = mysql_query($qGroupExists);
 if (mysql_num_rows($group_exists) > 0) {$return .= 'groupexists</changesuccess>'; bedone($return,$debug,$debuginfo);}
 else 
 {
  $result = mysql_query($qInsertGroup);
  $return .= 'groupadded</changesuccess>'; bedone($return,$debug,$debuginfo);
 }
}
if($admtype == "grpdel")
{
 $qDelete = "DELETE FROM authteam WHERE teamname='$teamname'";
 $qUpdateUser = "UPDATE authuser SET team='Ungrouped' WHERE team='$teamname'";
 if ($teamname == "Admin") {$return .= 'nodeladmin</changesuccess>'; bedone($return,$debug,$debuginfo);}
 elseif ($teamname == "Ungrouped") {$return .= 'nodelungrp</changesuccess>'; bedone($return,$debug,$debuginfo);}
 elseif ($teamname == "Temporary") {$return .= 'nodeltemp</changesuccess>'; bedone($return,$debug,$debuginfo);}
 $result = mysql_query($qUpdateUser);
 $result = mysql_query($qDelete);
 $return .= 'groupdeleted</changesuccess>'; bedone($return,$debug,$debuginfo);
}

//output all the XML

function bedone($return,$debug,$debuginfo) 
{
if($debug)
{
 $myFile = "/tmp/zsn_groupupdate_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 if($debuginfo) {fwrite($fh, "$debuginfo\n");}
 fclose($fh);
}

print ($return);
exit;
}
?>
