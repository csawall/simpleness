<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

session_start();
if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

if (!$connected) {echo 'Could not connect to database<br>';}

$query='SELECT DISTINCT family FROM plugins ORDER BY family';
$presult = mysql_query($query) or die ('Query failed: ' . mysql_error());

$return = '<nessusfamilies>';
while($row=mysql_fetch_array($presult))
{
 $return .= '<allfams>';
 $return .= '<family>'.$row[family].'</family>';
 $return .= '</allfams>';
}
$return .= '</nessusfamilies>';

if($debug)
{
 $myFile = "/tmp/zsn_getfams_debug.log";
 $fh = fopen($myFile, 'a') or die("Error!!");
 fwrite($fh, "$return\n");
 fwrite($fh, "$debuginfo\n");
 fclose($fh);
}
print($return);
?>
