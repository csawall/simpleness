<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

#session_start();
#if($_SESSION['loggedin'] != 1) {print "Please Login."; exit;}
include '../includes/vars.php';
include '../includes/constants.php';

//asign the data passed from Flex to variables
$qrtr_rpt = $_REQUEST['qrtrdisp'];
if (eregi("^[1234]Q[0-9][0-9]", $qrtr_rpt)) {}
else { die("Try hacking somebody else's site."); };

$debuginfo ='';
if($debug)
{
 $debuginfo .= 'Quarter = '.$qrtr_rpt.'\n';
}

//start outputting the XML
$return = "<topvulninfo>";

//Query the database to see if the given username/password combination is valid.
$query = 'SELECT results.scriptid, count(*) AS times,plugins.family FROM results,plugins WHERE NOT results.scriptid = "" AND results.scriptid = plugins.id AND risk = "'.$highrisk1.'" AND quarter = "'.$qrtr_rpt.'" GROUP BY scriptid ORDER BY times DESC LIMIT 10';
$result = mysql_query($query);

if($debug)
{
 $debuginfo .= 'Query = '.$query.'\n';
 $debuginfo .= 'MySQL err = '.mysql_error().'\n';
}

while($row=mysql_fetch_array($result))
{
 $return .= '<topvulns>';
 $return .= '<scriptid>'.$row[scriptid].'</scriptid>';
 $return .= '<times>'.$row[times].'</times>';
 $return .= '<family>'.$row[family].'</family>';
 $return .= '</topvulns>';
}
$return .= "</topvulninfo>";
bedone($return,$debug,$debuginfo);

//output all the XML

function bedone($return,$debug,$debuginfo)
{
 if($debug)
 {
  $myFile = "/tmp/zsn_topvulns_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  fwrite($fh, "$debuginfo\n");
  fclose($fh);
 }
print ($return);
exit;
}
?>
