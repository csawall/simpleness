<?
/***************************************************************************

simpleness - Simple Nessus Scanner and Web Reporting Interface
Copyright (C) 2004 - 2007 Chris Sawall

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this
program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
Suite 330, Boston, MA 02111-1307 USA

You may contact me at sawall -{at}- gmail -{dot}- com.
http://tech.stlsawall.com

-----------------------
This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php

***************************************************************************/

include '../includes/vars.php';
include '../includes/constants.php';

$qrtrdisp = mysql_real_escape_string(urldecode($_REQUEST['qrtrdisp']));
$return = '<auditdata>';
$debuginfo ='';

#DRAW MAIN PAGE WITH BASIC QUAERTERLY INFO AND GRAPHS
if(!isset($_REQUEST['pageview']) && !$_REQUEST['server'] && !$_REQUEST['quarter'])
{
  if(isset($_REQUEST['qrtrdisp'])) 
  {
   $qrtr_rpt = $_REQUEST['qrtrdisp'];
   if (eregi("^[1234]Q[0-9][0-9]", $qrtr_rpt)) {}
   else { die("Try hacking somebody else's site."); };
  }
  else
  {
   $query = 'SELECT id FROM quarters WHERE quarter="'.$qrtr.date("y").'"';
   $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
   if(!$row=mysql_fetch_array($result)) {$qrtr_rpt = $prevqrtr;}
   else{$qrtr_rpt = $qrtr.date("y");}
  }
  
  $return .= "<riskdata>";
  $return .= '<selectedqrtr>'.$qrtr_rpt.'</selectedqrtr>';

  //Find number of msft servers scanned
  $query = 'SELECT COUNT(DISTINCT(host)) AS count FROM quarters WHERE quarter="'.$qrtrdisp.'" AND os="msft"';
  $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
  while ($numsrvs = mysql_fetch_array($result))
  {
   $return .= '<os>Microsoft</os>';
   $return .= '<numsrvs>'.$numsrvs[count].'</numsrvs>';
   $tlms = $numsrvs[count];
  }
 
  //Find distinct hosts with high risk for msft
  $query = 'SELECT COUNT(DISTINCT(host)) AS count FROM results WHERE risk="'.$highrisk1.'" AND quarter="'.$qrtrdisp.'" AND os="msft" AND falsepos="n"';
  $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
  while ($hrcount = mysql_fetch_array($result))
  {
   $return .= '<disthrisk>'.$hrcount[count].'</disthrisk>';
   $worisk = $tlms - $hrcount[count];
   $return .= '<wohrisk>'.$worisk.'</wohrisk>';
  }
  //Find distinct host with high risks greater than 5 and 10
  $query = 'SELECT host, COUNT(risk) AS count FROM results WHERE risk="'.$highrisk1.'" AND quarter="'.$qrtrdisp.'" AND os="msft" GROUP BY host HAVING COUNT(risk)>4';
  $hm5count = mysql_num_rows(mysql_query($query)); 
  $hl5count = $tlms-$hm5count;
  if($tlms > 0)
  {
   $hl5percent = $hl5count/$tlms;
   $hl5rndprcnt = round($hl5percent, 2)*100;
  }
  else {$hl5rndprcnt = "0";}
  $return .= '<hm5cnt>'.$hm5count.'</hm5cnt>';
  $return .= '<hl5cnt>'.$hl5count.'</hl5cnt>';
  $return .= '<hl5rndprcnt>'.$hl5rndprcnt.'</hl5rndprcnt>';
  $query = 'SELECT host, COUNT(risk) AS count FROM results WHERE risk="'.$highrisk1.'" AND quarter="'.$qrtrdisp.'" AND os="msft" GROUP BY host HAVING COUNT(risk)>9';
  $hm10count = mysql_num_rows(mysql_query($query)); 
  $hl10count = $tlms-$hm10count;
  if($tlms > 0)
  {
   $hl10percent = $hl10count/$tlms;
   $hl10rndprcnt = round($hl10percent, 2)*100;
  }
  else {$hl10rndprcnt = "0";}
  $return .= '<hm10cnt>'.$hm10count.'</hm10cnt>';
  $return .= '<hl10cnt>'.$hl10count.'</hl10cnt>';
  $return .= '<hl10rndprcnt>'.$hl10rndprcnt.'</hl10rndprcnt>';
  
  // Find all risks for msft 
  $gotMShigh=0;$gotMSmed=0;$gotMSlow=0;
  $query = 'SELECT risk, COUNT(risk) AS count FROM results WHERE quarter="'.$qrtrdisp.'" AND os="msft" AND falsepos="N" GROUP BY risk';
  $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
  while ($riskinfo = mysql_fetch_array($result))
  {
   if($riskinfo[risk] == "$highrisk1") {$return .= '<highrisk>'.$riskinfo[count].'</highrisk>'; $gotMShigh=1;}
   if($riskinfo[risk] == "$medrisk1") {$return .= '<medrisk>'.$riskinfo[count].'</medrisk>'; $gotMSmed=1;} 
   if($riskinfo[risk] == "$lowrisk1") {$return .= '<lowrisk>'.$riskinfo[count].'</lowrisk>'; $gotMSlow=1;} 
  }
  if(!$gotMShigh) {$return .= '<highrisk>0</highrisk>';}
  if(!$gotMSmed) {$return .= '<medrisk>0</medrisk>';}
  if(!$gotMSlow) {$return .= '<lowrisk>0</lowrisk>';}
  $return .= "</riskdata>";
  $return .= "<riskdata>";
  $return .= '<selectedqrtr>'.$qrtr_rpt.'</selectedqrtr>';

  //Find number of unix servers scanned
  $query = 'SELECT COUNT(DISTINCT(host)) AS count FROM quarters WHERE quarter="'.$qrtrdisp.'" AND os="unix"';
  $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
  while ($numsrvs = mysql_fetch_array($result))
  {
   $return .= '<os>Unix</os>';
   $return .= '<numsrvs>'.$numsrvs[count].'</numsrvs>';
   $tlux = $numsrvs[count];
  }
  //Find distinct hosts with high risk for unix 
  $query = 'SELECT COUNT(DISTINCT(host)) AS count FROM results WHERE risk="'.$highrisk1.'" AND quarter="'.$qrtrdisp.'" AND os="unix" AND falsepos="n"';
  $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
  while ($hrcount = mysql_fetch_array($result))
  {
   $return .= '<disthrisk>'.$hrcount[count].'</disthrisk>';
   $worisk = $tlux - $hrcount[count];
   $return .= '<wohrisk>'.$worisk.'</wohrisk>';
  }
  //Find distinct host with high risks greater than 5 and 10
  $query = 'SELECT host, COUNT(risk) AS count FROM results WHERE risk="'.$highrisk1.'" AND quarter="'.$qrtrdisp.'" AND os="unix" GROUP BY host HAVING COUNT(risk)>4';
  $hm5count = mysql_num_rows(mysql_query($query)); 
  $hl5count = $tlux-$hm5count;
  if($tlux > 0) 
  {
   $hl5percent = $hl5count/$tlux;
   $hl5rndprcnt = round($hl5percent, 2)*100;
  }
  else {$hl5rndprcnt = "0";}
  $return .= '<hm5cnt>'.$hm5count.'</hm5cnt>';
  $return .= '<hl5cnt>'.$hl5count.'</hl5cnt>';
  $return .= '<hl5rndprcnt>'.$hl5rndprcnt.'</hl5rndprcnt>';
  $query = 'SELECT host, COUNT(risk) AS count FROM results WHERE risk="'.$highrisk1.'" AND quarter="'.$qrtrdisp.'" AND os="unix" GROUP BY host HAVING COUNT(risk)>9';
  $hm10count = mysql_num_rows(mysql_query($query)); 
  $hl10count = $tlux-$hm10count;
  if($tlux > 0) 
  {
   $hl10percent = $hl10count/$tlux;
   $hl10rndprcnt = round($hl10percent, 2)*100;
  }
  else {$hl10rndprcnt = "0";}
  $return .= '<hm10cnt>'.$hm10count.'</hm10cnt>';
  $return .= '<hl10cnt>'.$hl10count.'</hl10cnt>';
  $return .= '<hl10rndprcnt>'.$hl10rndprcnt.'</hl10rndprcnt>';
  
  // Find all risks for unix
  $gotUXhigh=0;$gotUXmed=0;$gotUXlow=0;
  $query = 'SELECT risk, COUNT(risk) AS count FROM results WHERE quarter="'.$qrtrdisp.'" AND os="unix" AND falsepos="N" GROUP BY risk';
  $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
  while ($riskinfo = mysql_fetch_array($result))
  {
   if($riskinfo[risk] == "$highrisk1") {$return .= '<highrisk>'.$riskinfo[count].'</highrisk>'; $gotUXhigh=1;} 
   if($riskinfo[risk] == "$medrisk1") {$return .= '<medrisk>'.$riskinfo[count].'</medrisk>'; $gotUXmed=1;} 
   if($riskinfo[risk] == "$lowrisk1") {$return .= '<lowrisk>'.$riskinfo[count].'</lowrisk>'; $gotUXlow=1;} 
  }
  if(!$gotUXhigh) {$return .= '<highrisk>0</highrisk>';}
  if(!$gotUXmed) {$return .= '<medrisk>0</medrisk>';}
  if(!$gotUXlow) {$return .= '<lowrisk>0</lowrisk>';}

  $return .= "</riskdata>";
 
 $started=0;
 $query = 'SELECT host, risk, COUNT(risk) AS rcount FROM results WHERE quarter = "'.$qrtrdisp.'" AND os="msft" GROUP BY host, risk ORDER BY host, risk'; 
 $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
 while ($hostdetails = mysql_fetch_array($result))
 {
  if ($host == $hostdetails[host]) {$gothost=1;}
  else 
  {
   if($host)
   {
    if(!$gotl) {$return .= '<lrisk>0</lrisk>';}
    if(!$gotm) {$return .= '<mrisk>0</mrisk>';}
    if(!$goth) {$return .= '<hrisk>0</hrisk>';}
   }
   $gothost=0; $goth=0; $gotm=0; $gotl=0;
   if ($started) {$return .= "</mshostdetails>";}
   $started=1;
  }
  $host = $hostdetails[host];
  if (!$gothost) {$return .= '<mshostdetails><hostname>'.$host.'</hostname>';}
  if ($hostdetails[risk] == "$lowrisk1") {$return .= '<lrisk>'.$hostdetails[rcount].'</lrisk>'; $gotl=1;}
  if ($hostdetails[risk] == "$medrisk1") {$return .= '<mrisk>'.$hostdetails[rcount].'</mrisk>'; $gotm=1;}
  if ($hostdetails[risk] == "$highrisk1") {$return .= '<hrisk>'.$hostdetails[rcount].'</hrisk>'; $goth=1;}
 }
 if($host)
 {
  if(!$gotl) {$return .= '<lrisk>0</lrisk>';}
  if(!$gotm) {$return .= '<mrisk>0</mrisk>';}
  if(!$goth) {$return .= '<hrisk>0</hrisk>';}
 }
 if(mysql_numrows($result)<1) {$return .= "<mshostdetails>";}
 $return .= "</mshostdetails>";

 $started=0;
 $query = 'SELECT host, risk, COUNT(risk) AS rcount FROM results WHERE quarter = "'.$qrtrdisp.'" AND os="unix" GROUP BY host, risk ORDER BY host, risk'; 
 $result = mysql_query($query) or die ('Query failed: ' . mysql_error());
 while ($hostdetails = mysql_fetch_array($result))
 {
  if ($host == $hostdetails[host]) {$gothost=1;}
  else 
  {
   if($host)
   {
    if(!$gotl) {$return .= '<lrisk>0</lrisk>';}
    if(!$gotm) {$return .= '<mrisk>0</mrisk>';}
    if(!$goth) {$return .= '<hrisk>0</hrisk>';}
   }
   $gothost=0; $goth=0; $gotm=0; $gotl=0;
   if ($started) {$return .= "</uxhostdetails>";}
   $started=1;
  }
  $host = $hostdetails[host];
  if (!$gothost) {$return .= '<uxhostdetails><hostname>'.$host.'</hostname>';}
  if ($hostdetails[risk] == "$lowrisk1") {$return .= '<lrisk>'.$hostdetails[rcount].'</lrisk>'; $gotl=1;}
  if ($hostdetails[risk] == "$medrisk1") {$return .= '<mrisk>'.$hostdetails[rcount].'</mrisk>'; $gotm=1;}
  if ($hostdetails[risk] == "$highrisk1") {$return .= '<hrisk>'.$hostdetails[rcount].'</hrisk>'; $goth=1;}
 } 
 if($host)
 {
  if(!$gotl) {$return .= '<lrisk>0</lrisk>';}
  if(!$gotm) {$return .= '<mrisk>0</mrisk>';}
  if(!$goth) {$return .= '<hrisk>0</hrisk>';}
 }
 if(mysql_numrows($result)<1) {$return .= "<uxhostdetails>";}
 $return .= "</uxhostdetails>";
 $return .= '</auditdata>';

 if($debug)
 {
  $myFile = "/tmp/zsn_audits_debug.log";
  $fh = fopen($myFile, 'a') or die("Error!!");
  fwrite($fh, "$return\n");
  fclose($fh);
 }
 
print($return); 
}
exit;
