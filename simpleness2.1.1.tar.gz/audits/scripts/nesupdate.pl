#!/usr/bin/perl
###################################################################
#
# simpleness - Simple Nessus Scanner and Web Reporting Interface
# Copyright (C) 2004 - 2007 Chris Sawall
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
# Suite 330, Boston, MA 02111-1307 USA
#
# You may contact me at sawall -{at}- gmail -{dot}- com.
# http://tech.stlsawall.com
#
#------------------------------------------
# This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php
#
###################################################################

$debug=0;
# Enable the following to run the script, but not execute the update
$debugonly=0;

# This section should be almost identical to the vars.php file
#
# Define root directory
$rootdir = "/srv/www/htdocs/audits";
# Definition for Windows based systems
@defmsnrc = ("Backdoors","CGI abuses","CGI abuses : XSS","FTP","Gain a shell remotely","Gain root remotely","General","Misc.","Peer-To-Peer File Sharing","Remote file access","RPC","Service detection","Settings","SMTP problems","SNMP","Useless services","Web Servers","Windows","Windows : Microsoft Bulletins","Windows : User management");
# Definition for Unix based systems
@defuxnrc = ("Backdoors","CGI abuses","CGI abuses : XSS","Default Unix Accounts","FTP","Gain a shell remotely","Gain root remotely","General","Misc.","Remote file access","RPC","Service detection","Settings","SMTP problems","SNMP","Useless services","Web Servers");
# Define path to update-nessusrc
# http://www.tifaware.com/perl/update-nessusrc/
$updatenrccmd = "$rootdir/rcfiles/update-nessusrc";
# Default custom rc files
$nessusmsrc = "$rootdir/rcfiles/.nessusrc.ms";
$nessusuxrc = "$rootdir/rcfiles/.nessusrc.ux";
# Identify specific plugins to ignore (not in vars.php)
# Must be comma delimited
# Example: $excludes = "10394,10396";
$excludes = "";

@jdefmsnrc = join(",",@defmsnrc);
@jdefuxnrc = join(",",@defuxnrc);

if($debugonly) {print "\n\nDEBUG ONLY ENABLED.  COMMANDS WILL NOT EXECUTE.\nIf you don't see any output, make sure to enable debug.\n\n";}
if($debug)
{
 print "Var Settings\n";
 print "------------------------------------\n";
 print "rootdir => $rootdir\n\n";
 print "default ms rc families => @jdefmsnrc\n\n";
 print "default ux rc families => @jdefuxnrc\n\n";
 print "default update command path => $updatenrccmd\n";
 print "default ms rc file => $nessusmsrc\n";
 print "default ux rc file => $nessusuxrc\n\n";
}

$updatems .= "$updatenrccmd -f \"@jdefmsnrc\"";
$updateux .= "$updatenrccmd -f \"@jdefuxnrc\"";

if($excludes)
{
 if($debug) {print "Adding Exclude information to update command\n\n";}
 $updatems .= " -x \"$excludes\""; 
 $updateux .= " -x \"$excludes\""; 
}

$updatems .= " $nessusmsrc";
$updateux .= " $nessusuxrc";

if($debug)
{
 print "Update commands\n";
 print "------------------------------------\n";
 print "ms update => $updatems\n\n";
 print "ux update => $updateux\n\n";
 print "\nStarting updates for RC files\n";
}

if($debug) {print "\tUpdating default MS rc file\n";}
if(!$debugonly) 
{
 system `$updatems >& /dev/null`;
 system `chmod 644 $nessusmsrc`;
}

if($debug) {print "\tUpdating default Unix rc file\n";}
if(!$debugonly) 
{
 system `$updateux >& /dev/null`;
 system `chmod 644 $nessusuxrc`;
}


if($debug) {print "Done updating files.\n\n";}


