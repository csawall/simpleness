#!/usr/bin/perl
#===========================================================#
# Nessus NBE Importer 					    #
# Copyright 2004 - 2007 Chris Sawall                        #	
#                   sawall -[at]- gmail -[dot]- com         #
# http://tech.stlsawall.com				    #
#							    #
$written = "07/03/05";					    #
$lastupdated = "01/20/06";				    #
$version = "1.0";					    #
#===========================================================#
#===========================================================#
#
# simpleness - Simple Nessus Scanner and Web Reporting Interface
# Copyright (C) 2006 Chris Sawall
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
# Suite 330, Boston, MA 02111-1307 USA
#
# You may contact me at sawall -{at}- gmail -{dot}- com.
# http://tech.stlsawall.com
#
#------------------------------------------
# This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php
#
#===========================================================#
#===========================================================#
# This code is a highly modified version of the nessQuick   #
# perl script found at:                                     # 
# http://www.atriskonline.com/archives/00000048.shtml       #
#                                                           #
# The only parts that are really the same are the functions #
# to split the fields from the NBE file and the functions   #
# used to actually do the main inserts into MySQL.          # 
#===========================================================#

use DBI;
use Getopt::Std;
######################
# Database Connection Settings 
#
$dbidriver="mysql";
$database = "nessus";
$hostname = "localhost";
$username = "nesuser";
$password = "PASSWORD";
#
######################

#Set available options
getopts('hvf:o:q:') or usage();
usage() if $opt_h;

#Verify input file is set
if(!$opt_f) {print "***No import file specified.***\nExiting...\n"; usage();}
$infile = $opt_f;
print STDERR "Input file ==>$infile\n" if $opt_v;
chomp $infile;

#Set time variable for DB
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
if($mday < 10) { $mday = "0".$mday; }
$mon += 1;
if($mon < 10) { $mon = "0".$mon; }
$year += 1900;
if($sec < 10) { $sec = "0".$sec; }
if($min < 10) { $min = "0".$min; }
if($hour < 10) { $hour = "0".$hour; }

$now = "$year-$mon-$mday $hour:$min:$sec";
$yr = substr($year, 2, 2);

#Verify quarter variable is set
if(!$opt_q) {print "***No quarter/year specified.***\nExiting...\n"; usage();}
$quarter = $opt_q;
if($quarter !~ /\dQ$yr/) {print "***Quarter/Year info in wrong format.***\nExiting...\n"; usage();}
print STDERR "Quarter/Year ==>$infile\n" if $opt_v;

#Verify proper OS is set
if(!$opt_o) {print "***No OS specified.***\nExiting...\n"; usage();}
$os = $opt_o;
if($os !~ /msft|unix/) {print "***OS info in wrong format.***\nExiting...\n"; usage();}
print STDERR "OS ==>$os\n" if $opt_v;

#Connect to DB
$dbh = DBI->connect("DBI:mysql:$database:$hostname", $username, $password);
die "Cannot log into database.  Please try again later.\n" unless $dbh;
if($opt_v) {print "Connected to $database... \n";}

#Open file for input
open(INPUT,"<$infile")||die("Can't open report file");
if($opt_v) {print "Opened $infile... \n";}

#Go through file and input data into DB
if($opt_v) {print "Processing input file... \n";}
while (<INPUT>)
  {
  print "current line ==> $_\n" if $opt_v;

#Clear all variables 
	$infield1 = " ";
	$infield2 = " ";
	$infield3 = " ";
	$infield4 = " ";
	$infield5 = " ";
	$infield6 = " ";
	$infield7 = " ";
	$insertid = $sth->{mysql_insertid}; 

#Split fields
	($infield1,$infield2,$infield3,$infield4,$infield5,$infield6,$infield7)=split(/\|/,$_);

#Go through file and if device has already been scanned and in the DB, skip it.
#Don't want duplicate data on same server in same quarter.
	$scanned = exec_sselect("SELECT scanned FROM `quarters` where host = '$infield3' AND quarter = '$quarter'");
	if(/timestamps\|\|\|scan_start|scan_end/) {next;}
	if(($scanned eq "Y") && ($infield3 ne ""))
	{
		print "\t***$infield3 has already been scanned this quarter.***\n" if $opt_v;
		next;
	}
	
#If host not already in DB, start importing first data to DB 
	if(/timestamps\|\s*\|(\S+)\|host_start/)
	{
		$scanhost = $1;
		if($opt_v) {print "\thostname ==> $scanhost\n";}
		if(!exec_sselect("SELECT host FROM `quarters` where host = '$scanhost' AND `quarter` = '$quarter'"))
		{
			if($opt_v)
			{
				print "\t***************************\n";
				print "\tInserting\:\n\t hostname ==> $scanhost\n\tquarter ==> $quarter\n";
			}
			exec_sql("insert into quarters (id, host, quarter, os, scanned) values ('$insertid','$scanhost','$quarter','$os','N')");	
			$scanned = exec_sselect("SELECT scanned FROM `quarters` where host = '$infield3' AND quarter = '$quarter'");
		}
	}

#Finish inputting data to DB by marking it as being scanned for the quarter
	if($_ =~ /timestamps\|\|\w+\|host_end/) 
	{
		if($opt_v) {print "Found end of scan for host: $infield3.\n";}
		exec_sql("update quarters set scanned = 'Y' where host = '$infield3'");
	}

# Translate ; to \n for newline
	$infield7 =~ tr/;/\n/;

# Translate " to \"
	$infield7 =~ tr/"/'/;

# Convert "infield6 factor" to infield6 value HIGH/MEDIUM/LOW
#
# Change added 01/23/06
# Changed following to accomodate changes in NBE files in Nessus 3.x
# Instead of matching "Risk factor : Level"
# Now matching on "Risk factor{anything}Level" to account for new "\n" before Level
# Also added to account for Risk factor of Critical. 

        $infield6="0";
        $infield6='3' if ($infield7 =~ /Risk factor.*Critical/);
        $infield6='3' if ($infield7 =~ /Risk factor.*Serious/);
        $infield6='3' if ($infield7 =~ /Risk factor.*High/);
        $infield6='2' if ($infield7 =~ /Risk factor.*Medium/);
        $infield6='2' if ($infield7 =~ /Risk factor.*Medium\/Low/);
        $infield6='1' if ($infield7 =~ /Risk factor.*Low\/Medium/);
        $infield6='1' if ($infield7 =~ /Risk factor.*Low/);


# Remove "infield6 factor" from $infield7 field
	$infield7=~ s/Risk factor.*//;

# Insert values into appropriate table
	if ($infield1 eq "results") {
		$dbh->do("insert into results (id, quarter, os, domain, host, service, scriptid, risk, msg, falsepos) 
		values ('$insertid','$quarter','$os','$infield2','$infield3','$infield4','$infield5','$infield6',\"$infield7\",'N')
		");
	}
	else {
		$dbh->do("insert into timestamps (id, quarter, os, unused, host, progress, timestamp) 
		values ('$insertid','$quarter', '$os', '$infield2','$infield3','$infield4','$infield5')
		");
	}
  }


if($opt_v) {print "Finished processing input file... \n";}

#Close input file
close INPUT;
$dbh->disconnect or die "Failed to disconnect : $DBI::errstr\n";
exit(0); 

sub exec_sql {
        my ($sqlstatement) = @_;
        my $sel;

        print STDERR "Executing $sqlstatement\n" if $opt_v;
        $sel = $dbh->prepare($sqlstatement);
        $sel->execute;
}


sub exec_sselect {
# Exect a statement that returns a single column
        my ($sqlstatement) = @_;
        $returnval = "";
        my $sel;

        print STDERR "Executing $sqlstatement\n" if $opt_v;
        $sel = $dbh->prepare(qq{$sqlstatement});
        $sel->execute;
        $returnval = $sel->fetchrow_array;

        if ( $returnval ) {
                print STDERR "Value retrieved is $returnval\n" if $opt_v;
        } else {
                print STDERR "ERROR: Query returned empty value\n" if $opt_v;
	#	$returnval = "Empty";
        }
        return $returnval;
}

sub usage()
{
print STDERR << "EOF";

This program does...

usage: importness.pl [-hv] [-f file] -o [msft|unix] [-q quarter/year]

-h         : This (help) message
-v         : Verbose output
-f file    : File containing usersnames, one per line
-o OS	   : List out if the OS is Microsoft or Unix based
-q quarter : Current quarter for scans, i.e., 1Q05
	     the format for this option should be:
		Quarter -> 1Q, 2Q, 3Q or 4Q (for each quarter)
		Year -> Last two digits of the current year
			The Year MUST be the current year

example: importness.pl -v -f filename -o msft -q 1Q05

EOF
exit;
}


