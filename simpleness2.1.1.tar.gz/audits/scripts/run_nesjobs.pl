#!/usr/bin/perl
#===========================================================#
#
# simpleness - Simple Nessus Scanner and Web Reporting Interface
# Copyright (C) 2004 - 2007 Chris Sawall
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
# Suite 330, Boston, MA 02111-1307 USA
#
# You may contact me at sawall -{at}- gmail -{dot}- com.
# http://tech.stlsawall.com
#
#------------------------------------------
# This is the GNU GPL. http://www.opensource.org/licenses/gpl-license.php
#
#===========================================================#

use DBI;
use Getopt::Std;
######################
# Database Connection Settings 
#
$dbidriver="mysql";
$database = "nessus";
$hostname = "localhost";
$username = "nesuser";
$password = "PASSWORD";
#
######################
# Define path to mail program
$mailprog = "/usr/bin/mail";

#Set available options
getopts('hv') or usage();
usage() if $opt_h;

#Set time variable for DB
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
if($mday < 10) { $mday = "0".$mday; }
$mon += 1;
if($mon < 10) { $mon = "0".$mon; }
$year += 1900;
if($sec < 10) { $sec = "0".$sec; }
if($min < 10) { $min = "0".$min; }
if($hour < 10) { $hour = "0".$hour; }

$now = "$mon$mday$hour$min";

#Connect to DB
$dbh = DBI->connect("DBI:mysql:$database:$hostname", $username, $password);
die "Cannot log into database.  Please try again later.\n" unless $dbh;
if($opt_v) {print "Connected to $database... \n";}

###############################
#
# qdata[0]=id
# qdata[1]=time
# qdata[2]=job
# qdata[3]=job display
# qdata[4]=job dir
# qdata[5]=username
# qdata[6]=email
# qdata[7]=scanreason
# qdata[8]=sendinfosec email setting
# qdata[9]=infosec email
# qdata[10]=convert to html command
# qdata[11]=database import command
# qdata[12]=import to db setting
#
###############################

$querystring = "SELECT * FROM scheduled";
$query = $dbh->prepare($querystring);
$query->execute;
while (@qdata = $query->fetchrow_array())
{
 if($opt_v)
 {
  print "field 0 = $qdata[0]\n";
  print "field 1 = $qdata[1]\n";
  print "field 2 = $qdata[2]\n";
  print "field 3 = $qdata[3]\n";
  print "field 4 = $qdata[4]\n";
  print "field 5 = $qdata[5]\n";
  print "field 6 = $qdata[6]\n";
  print "field 7 = $qdata[7]\n";
  print "field 8 = $qdata[8]\n";
  print "field 9 = $qdata[9]\n";
  print "field 10 = $qdata[10]\n";
  print "field 11 = $qdata[11]\n";
  print "field 12 = $qdata[12]\n";
 }
 if($now>$qdata[1])
 {
  if($opt_v) {print "Starting Nessus job.\n"}
  system `echo $qdata[3] | $mailprog -s "Starting Nessus" $qdata[6]`;
  if($qdata[8] == "1") {system `cat $qdata[4]/$qdata[3] | $mailprog -s "Starting Nessus for $qdata[5] ($qdata[7])" $qdata[9]`;}
  $delqstring = "DELETE FROM scheduled WHERE id='$qdata[0]'";
  $dquery = $dbh->prepare($delqstring);
  $dquery->execute;
  system `$qdata[2]`;
  if($opt_v) {print "Nessus done.\n"}
  if($opt_v) {print "Scan done.  Converting to HTML.\n";}
  system `$qdata[10]`;
  system `echo "Done scanning" | mail -s "Nessus Done" -a $qdata[4]/$qdata[3].html $qdata[6]`;
  if(($qdata[7] == "Quarterly Scan") && ($qdata[12] == "true"))
  {
   if($opt_v) {print "Conversion done.  Importing to DB.\n";}
   system `$qdata[11]`;
   if($opt_v) {print "Importing complete.\n";}
  }
  else {print "Conversion done. NOT importing data to DB.\n";}
 }
 else { if($opt_v) {print "No jobs to run.\n"}}
}

#Close input file
$dbh->disconnect or die "Failed to disconnect : $DBI::errstr\n";
exit(0); 

sub usage()
{
print STDERR << "EOF";

This program does...

usage: run_nesjobs.pl [-hv]

-h         : This (help) message
-v         : Verbose output

example: run_nesjobs.pl -v 

EOF
exit;
}


